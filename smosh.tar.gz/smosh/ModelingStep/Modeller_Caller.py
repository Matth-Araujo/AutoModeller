import subprocess
class Modeller_Caller:
    def __init__(self):
        self.modeller_executable = "python2"
        self.process = None
    def run(self,script):
        process = subprocess.Popen([self.modeller_executable,script])
        return process.wait()
